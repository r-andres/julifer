/**
 * Validates the form in client side.
 */
$(document).ready(function(){		   
	jQuery.validator.addMethod("regex", function( value, element, regexp ) {
			  if (regexp.constructor != RegExp)
	              regexp = new RegExp(regexp);
			  else if (regexp.global)
				  regexp.lastIndex = 0;

			  return this.optional(element) || regexp.test(value);
		},  "Please check your input.");
	jQuery.validator.messages.required = "";
	$("#myForm").validate({
		invalidHandler: function(e, validator) {
		var errors = validator.numberOfInvalids();
		if (errors) {
			var message = 'Por favor, compruebe los campos se&ntilde;alados en rojo.';
			$("div.error span").html(message);
			$("div.error").show();
		} else {
			$("div.error").hide();
		}
	},
	submitHandler: function() {
		$("div.error").hide();
		sendForm('MaterialList','save',$("#id").val());
	},
	onkeyup: true,
			rules: {
				preciounitario : {
					regex: /^\d+\.?\d*$/
				}
			},
			messages: {
				descripcion: {
					required: " "
				},	
				preciounitario : {
					required: " ",
					regex: "Precio debe ser un n&uacute;mero."
				}
			},
			debug:true
	});

	$(".resize").vjustify();
	$("div.buttonSubmit").hoverClass("buttonSubmitHover");

	// toggle optional billing address
	var subTableDiv = $("div.subTableDiv");
	var toggleCheck = $("input.toggleCheck");
	toggleCheck.is(":checked")
	? subTableDiv.hide()
			: subTableDiv.show();
	$("input.toggleCheck").click(function() {
		if (this.checked == true) {
			subTableDiv.slideUp("medium");
			$("form").valid();
		} else {
			subTableDiv.slideDown("medium");
		}
	});
});



$.fn.vjustify = function() {
    var maxHeight=0;
    $(".resize").css("height","auto");
    this.each(function(){
        if (this.offsetHeight > maxHeight) {
          maxHeight = this.offsetHeight;
        }
    });
    this.each(function(){
        $(this).height(maxHeight);
        if (this.offsetHeight > maxHeight) {
            $(this).height((maxHeight-(this.offsetHeight-maxHeight)));
        }
    });
};

$.fn.hoverClass = function(classname) {
	return this.hover(function() {
		$(this).addClass(classname);
	}, function() {
		$(this).removeClass(classname);
	});
};
/*

function clear_form(form) {
    $(form).find(':input').each(function() {
        switch(this.type) {
            case 'password':
            case 'select-multiple':
            case 'select-one':
            case 'text':
            case 'textarea':
                $(this).val('');
                break;
            case 'checkbox':
            case 'radio':
                this.checked = false;
        }
    });
}
*/

